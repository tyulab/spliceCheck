/********* Sequence input routines for CLUSTAL W *******************/
/* DES was here.  FEB. 1994 */
/* Now reads PILEUP/MSF and CLUSTAL alignment files */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "leon.h"	

#define MIN(a,b) ((a)<(b)?(a):(b))



/*
*	Prototypes
*/
static sint get_seq_with_index(SEQ *seqs,sint nseqs,sint ii);
static void xmlprinttext(FILE *fd,char *el,char *content);
static int SeqGCGCheckSum(char *seq, int len);


/*
 *	Global variables
 */
static sint debug;


Boolean open_alignment_output(char *filename,ALNOUT_OPTPTR alnout_opt)
{

	if(!alnout_opt->output_clustal && !alnout_opt->output_nbrf && !alnout_opt->output_gcg &&
		 !alnout_opt->output_rsf && !alnout_opt->output_tfa) {
                error("You must select an alignment output format");
                return FALSE;
        }

	if(alnout_opt->output_clustal) 
		if((alnout_opt->clustal_outfile=open_output_file(filename, "CLUSTAL", "aln", alnout_opt->clustal_outname))==NULL) return FALSE;

	if(alnout_opt->output_nbrf) 
		if((alnout_opt->nbrf_outfile=open_output_file(filename, "NBRF", "pir", alnout_opt->nbrf_outname))==NULL) return FALSE;

	if(alnout_opt->output_gcg) 
		if((alnout_opt->gcg_outfile=open_output_file(filename, "GCG", "msf", alnout_opt->gcg_outname))==NULL) return FALSE;

	if(alnout_opt->output_tfa) 
		if((alnout_opt->tfa_outfile=open_output_file(filename, "FASTA", "tfa", alnout_opt->tfa_outname))==NULL) return FALSE;

	if(alnout_opt->output_rsf) {
		if((alnout_opt->rsf_outfile=open_output_file(filename, "RSF", "rsf", alnout_opt->rsf_outname))==NULL) return FALSE;
	}

	return TRUE;
}

/* gets a filename from the user and opens the file 
returns the file handle (the filename is written into char *file_name) */

FILE *  open_output_file(char *in_name, char *prompt, char *file_extension, char *out_name)
{
	char temp[FILENAMELEN+1];
	char path[FILENAMELEN+1];
	char local_prompt[MAXLINE];
	FILE * file_handle;

/* if the output filename is already specified, just open the file and return */
	file_handle = open_explicit_file(out_name);
	return file_handle;
}

/*
	writes the selected sequences to an output file.
	Only those sequences with output_index>=0 will be included in the file.
	Sequences will be written in order of output_index.
	eg. the sequence with output_index=3 will be the third sequence written to the file.

	mult_aln	the sequences
	alnout_opt	output options, including file format etc.
	ss_opt		secondary structure options
*/

void create_alignment_output(ALN mult_aln,ALNOUT_OPT alnout_opt,SS_OPT ss_opt)
{
	sint i,length,nseqs;

	length=nseqs=0;
        for (i=0;i<mult_aln.nseqs;i++)
                if (mult_aln.seqs[i].output_index>=0) {
			nseqs++;
			if(length < mult_aln.seqs[i].len) length = mult_aln.seqs[i].len;
		}


	if(alnout_opt.output_clustal) {
		clustal_out(alnout_opt.clustal_outfile, 0, length, alnout_opt.seq_numbers,mult_aln,ss_opt);
		fclose(alnout_opt.clustal_outfile);
	}
	if(alnout_opt.output_nbrf)  {
		nbrf_out(alnout_opt.nbrf_outfile, 0, length, mult_aln);
		fclose(alnout_opt.nbrf_outfile);
	}
	if(alnout_opt.output_gcg)  {
		gcg_out(alnout_opt.gcg_outfile, 0, length, mult_aln);
		fclose(alnout_opt.gcg_outfile);
	}
	if(alnout_opt.output_tfa)  {
		tfa_out(alnout_opt.tfa_outfile, 0, length, mult_aln);
		fclose(alnout_opt.tfa_outfile);
	}
	if(alnout_opt.output_rsf)  {
		rsf_out(alnout_opt.rsf_outfile, 0, length, mult_aln, alnout_opt);
		fclose(alnout_opt.rsf_outfile);
	}
}

void clustal_out(FILE *clusout, sint fres, sint len,Boolean seq_numbers,ALN mult_aln,SS_OPT ss_opt)
{
	static char *seq1;
	static sint *seq_no;
	static sint *print_seq_no;
	char *revision_level;
	char 	    temp[MAXLINE];
	char c;
	char val;
	sint ii,lv1,catident1[NUMRES],catident2[NUMRES],ident,chunks;
	sint i,j,k,l;
	sint pos,ptr,nseqs;
	sint line_length;
	sint max_aln_length,max_names;

/*These are all the positively scoring groups that occur in the Gonnet Pam250
matrix. There are strong and weak groups, defined as strong score >0.5 and
weak score =<0.5. Strong matching columns to be assigned ':' and weak matches
assigned '.' in the clustal output format.
*/

char *res_cat1[] = {
                "sta",
                "neqk",
                "nhqk",
                "ndeq",
                "qhrk",
                "milv",
                "milf",
                "hy",
                "fyw",
                NULL };

char *res_cat2[] = {
                "csa",
                "atv",
                "sag",
                "stnk",
                "stpa",
                "sgnd",
                "sndeqk",
                "ndeqhk",
                "neqhrk",
                "fvlim",
                "hfy",
                NULL };


	nseqs=0;
        for (i=0;i<mult_aln.nseqs;i++)
                if (mult_aln.seqs[i].output_index>=0) 
			nseqs++;

	seq_no = (sint *)ckalloc((nseqs+1) * sizeof(sint));
	print_seq_no = (sint *)ckalloc((nseqs+1) * sizeof(sint));
	max_aln_length=max_names=0;
	for (i=0;i<mult_aln.nseqs;i++)
        {
		if(mult_aln.seqs[i].output_index>=0) {
			 if(mult_aln.seqs[i].len>max_aln_length) max_aln_length=mult_aln.seqs[i].len;
			if(strlen(mult_aln.seqs[i].name)>max_names) max_names=strlen(mult_aln.seqs[i].name);
			print_seq_no[i] = seq_no[i] = 0;
                	for(j=0;j<fres;j++) {
				val = mult_aln.seqs[i].data[j];
				if(isalpha(val)) seq_no[i]++;
			}
		}
        }


	seq1 = (char *)ckalloc((max_aln_length+1) * sizeof(char));

	fprintf(clusout,"CLUSTAL multiple sequence alignment\n\n");

/* decide the line length for this alignment - maximum is LINELENGTH */
	line_length=PAGEWIDTH-max_names;
	line_length=line_length-line_length % 10; /* round to a multiple of 10*/
	if (line_length > LINELENGTH) line_length=LINELENGTH;

	chunks = len/line_length;
	if(len % line_length != 0)
		++chunks;
		
	for(lv1=0;lv1<chunks;lv1++) {
		pos = lv1*line_length;
		ptr = (len<pos+line_length) ? len : pos+line_length;

		fprintf(clusout,"\n");
		
		for(ii=0;ii<nseqs;ii++) {
			i=get_seq_with_index(mult_aln.seqs,mult_aln.nseqs,ii);
			print_seq_no[i] = 0;
			for(j=pos;j<ptr;j++) {
				if (j+fres<mult_aln.seqs[i].len)
					val = mult_aln.seqs[i].data[j+fres];
				else val = -3;
				if(val == EOS) break;
				else if(!isalpha(val))
                                        seq1[j]='-';
				else {
					seq1[j]=toupper(val);
					seq_no[i]++;
					print_seq_no[i]=1;
				}
			}
			for(;j<ptr;j++) seq1[j]='-';
			strncpy(temp,&seq1[pos],ptr-pos);
			temp[ptr-pos]=EOS;
			fprintf(clusout,"%-*s %s",max_names+5,mult_aln.seqs[i].name,temp);
			if (seq_numbers && print_seq_no[i])
					fprintf(clusout," %d",seq_no[i]);
			fprintf(clusout,"\n");
		}
	
		for(i=pos;i<ptr;i++) {
			seq1[i]=' ';
			ident=0;
			for(j=0;res_cat1[j]!=NULL;j++) catident1[j] = 0;
			for(j=0;res_cat2[j]!=NULL;j++) catident2[j] = 0;
			for(j=0;j<mult_aln.nseqs;j++) {
				if(isalpha(mult_aln.seqs[0].data[i])) {
					if(mult_aln.seqs[0].data[i] == mult_aln.seqs[j].data[i])
					++ident;
					for(k=0;res_cat1[k]!=NULL;k++) {
					        for(l=0;(c=res_cat1[k][l]);l++) {
							if (mult_aln.seqs[j].data[i]==c)
							{
								catident1[k]++;
								break;
							}
						}
					}
					for(k=0;res_cat2[k]!=NULL;k++) {
					        for(l=0;(c=res_cat2[k][l]);l++) {
							if (mult_aln.seqs[j].data[i]==c)
							{
								catident2[k]++;
								break;
							}
						}
					}
				}
			}
			if(ident==mult_aln.nseqs)
				seq1[i]='*';
			else if (!mult_aln.dnaflag) {
				for(k=0;res_cat1[k]!=NULL;k++) {
					if (catident1[k]==mult_aln.nseqs) {
						seq1[i]=':';
						break;
					}
				}
				if(seq1[i]==' ')
					for(k=0;res_cat2[k]!=NULL;k++) {
						if (catident2[k]==mult_aln.nseqs) {
							seq1[i]='.';
							break;
						}
					}
			}
		}
		strncpy(temp,&seq1[pos],ptr-pos);
		temp[ptr-pos]=EOS;
		for(k=0;k<max_names+6;k++) fprintf(clusout," ");
		fprintf(clusout,"%s\n",temp);
	}
		

	seq1=ckfree((void *)seq1);
	
}


static sint get_seq_with_index(SEQ *seqs,sint nseqs,sint ii)
{
	sint i;

	for(i=0;i<nseqs;i++) {
		if(seqs[i].output_index==ii) break;
	}

	return i;
}



void gcg_out(FILE *gcgout, sint fres, sint len, ALN mult_aln)
{
	char *seq, residue;
	char val;
	sint *all_checks;
	sint i,ii,chunks,block,nseqs;
	sint j,pos1,pos2;	
	sint max_aln_length,max_names;
	long grand_checksum;

	nseqs=0;
        for (i=0;i<mult_aln.nseqs;i++)
                if (mult_aln.seqs[i].output_index>=0) 
			nseqs++;

	max_aln_length=max_names=0;
	for(i=0; i<mult_aln.nseqs; i++) {
		if(mult_aln.seqs[i].output_index>=0 && mult_aln.seqs[i].len>max_aln_length) max_aln_length=mult_aln.seqs[i].len;
		if(mult_aln.seqs[i].output_index>=0 && strlen(mult_aln.seqs[i].name)>max_names) max_names=strlen(mult_aln.seqs[i].name);
	}

	seq = (char *)ckalloc((max_aln_length+1) * sizeof(char));
	all_checks = (sint *)ckalloc((mult_aln.nseqs+1) * sizeof(sint));
	
	for(i=0; i<nseqs; i++) {
		if(mult_aln.seqs[i].output_index>=0) {
			for(j=fres; j<fres+len; j++) {
				val = mult_aln.seqs[i].data[j];
				if(val == EOS) break;
				else if(!isalpha(val))
					residue = '.';
                        	else {
					residue = val;
				}
				seq[j-fres] = toupper(residue);
			}
/* pad any short sequences with gaps, to make all sequences the same length */
			for(; j<fres+len; j++) 
				seq[j-fres] = '.';
			all_checks[i] = SeqGCGCheckSum(seq, (int)len);
		}
	}	

	grand_checksum = 0;
	for(i=0; i<mult_aln.nseqs; i++) if(mult_aln.seqs[i].output_index>=0) grand_checksum += all_checks[i];
	grand_checksum = grand_checksum % 10000;
        fprintf(gcgout,"PileUp\n\n");
	fprintf(gcgout,"\n\n   MSF:%5d  Type: ",(pint)len);
	if(mult_aln.dnaflag)
		fprintf(gcgout,"N");
	else
		fprintf(gcgout,"P");
	fprintf(gcgout,"    Check:%6ld   .. \n\n", (long)grand_checksum);

	for(ii=0; ii<nseqs; ii++)  {
		i = get_seq_with_index(mult_aln.seqs,mult_aln.nseqs,ii);
		fprintf(gcgout,
			" Name: %s oo  Len:%5d  Check:%6ld  Weight:  %.1f\n",
			mult_aln.seqs[i].name,(pint)len,(long)all_checks[i],(float)mult_aln.seqs[i].weight*100.0/(float)INT_SCALE_FACTOR);
        }
	fprintf(gcgout,"\n//\n");  

	chunks = len/GCG_LINELENGTH;
	if(len % GCG_LINELENGTH != 0) ++chunks;

	for(block=0; block<chunks; block++) {
		fprintf(gcgout,"\n\n");
		pos1 = (block * GCG_LINELENGTH);
		pos2 = (len<pos1+GCG_LINELENGTH)? len : pos1+GCG_LINELENGTH;
		for(ii=0; ii<nseqs; ii++) {
			i = get_seq_with_index(mult_aln.seqs,mult_aln.nseqs,ii);
			fprintf(gcgout,"\n%-*s ",max_names+5,mult_aln.seqs[i].name);
			for(j=pos1; j<pos2; j++) {
/*
    JULIE -
    check for sint sequences - pad out with '.' characters to end of alignment
*/
				if (j+fres<mult_aln.seqs[i].len)
					val = mult_aln.seqs[i].data[j+fres];
				else val = -3;
				if(val == EOS)
					residue = '.';
				else if(!isalpha(val))
					residue = '.';
				else {
					residue = toupper(val);
				}
				fprintf(gcgout,"%c",residue);
				if((j+1) % 10 == 0) fprintf(gcgout," ");
			}
		}
	}

	seq=ckfree((void *)seq);
	all_checks=ckfree((void *)all_checks);
	
	fprintf(gcgout,"\n\n");
}


void fasta_out(FILE *out, sint fres, sint len, ALN mult_aln)
{
	char *seq, residue;
	char val;
	sint i,ii;
	sint j,slen,nseqs;	
	sint line_length;
	sint max_aln_length,max_names;

	nseqs=0;
	max_aln_length=max_names=0;
	for(i=0; i<mult_aln.nseqs; i++)  {
                if (mult_aln.seqs[i].output_index>=0) {
			if(mult_aln.seqs[i].len>max_aln_length) max_aln_length=mult_aln.seqs[i].len;
			if(strlen(mult_aln.seqs[i].name)>max_names) max_names=strlen(mult_aln.seqs[i].name);
			nseqs++;
		}
	}

	seq = (char *)ckalloc((max_aln_length+1) * sizeof(char));
	
/* decide the line length for this alignment - maximum is LINELENGTH */
	line_length=PAGEWIDTH-max_names;
	line_length=line_length-line_length % 10; /* round to a multiple of 10*/
	if (line_length > LINELENGTH) line_length=LINELENGTH;

	for(ii=0; ii<nseqs; ii++) {
		i = get_seq_with_index(mult_aln.seqs,mult_aln.nseqs,ii);
		fprintf(out, ">%s\n%s\n", mult_aln.seqs[i].name, mult_aln.seqs[i].title);
		slen = 0;
		for(j=fres; j<fres+len; j++) {
			val = mult_aln.seqs[i].data[j];
			if(val == EOS)
				break;
			else if(!isalpha(val))
				residue = '-';
			else {
				residue = val;
			}
			seq[j-fres] = toupper(residue);
			slen++;
		}
		for(j=0; j<slen; j++) {
			fprintf(out,"%c",seq[j]);
			if(((j+1) % line_length == 0) || (j == slen-1)) 
				fprintf(out,"\n");
		}
		fprintf(out,"\n");
	}	

	seq=ckfree((void *)seq);
}




void nbrf_out(FILE *nbout, sint fres, sint len, ALN mult_aln)
{
	char *seq, residue;
	char val;
	sint i,ii,nseqs;
	sint j,slen;	
	sint line_length;
	sint max_aln_length,max_names;

	nseqs=0;
	max_aln_length=max_names=0;
	for(i=0; i<mult_aln.nseqs; i++)  {
                if (mult_aln.seqs[i].output_index>=0) {
			if(mult_aln.seqs[i].len>max_aln_length) max_aln_length=mult_aln.seqs[i].len;
			if(strlen(mult_aln.seqs[i].name)>max_names) max_names=strlen(mult_aln.seqs[i].name);
			nseqs++;
		}
	}

	seq = (char *)ckalloc((max_aln_length+1) * sizeof(char));
	
/* decide the line length for this alignment - maximum is LINELENGTH */
	line_length=PAGEWIDTH-max_names;
	line_length=line_length-line_length % 10; /* round to a multiple of 10*/
	if (line_length > LINELENGTH) line_length=LINELENGTH;

	for(ii=0; ii<nseqs; ii++) {
		i = get_seq_with_index(mult_aln.seqs,mult_aln.nseqs,ii);
		fprintf(nbout, mult_aln.dnaflag ? ">DL;" : ">P1;");
		fprintf(nbout, "%s\n%s\n", mult_aln.seqs[i].name, mult_aln.seqs[i].title);
		slen = 0;
		for(j=fres; j<fres+len; j++) {
			val = mult_aln.seqs[i].data[j];
			if(val == EOS)
				break;
			else if(!isalpha(val))
				residue = '-';
			else {
				residue = val;
			}
			seq[j-fres] = toupper(residue);
			slen++;
		}
		for(j=0; j<slen; j++) {
			fprintf(nbout,"%c",seq[j]);
			if(((j+1) % line_length == 0) || (j == slen-1)) 
				fprintf(nbout,"\n");
		}
		fprintf(nbout,"*\n");
	}	

	seq=ckfree((void *)seq);
}


void rsf_out(FILE *rsfout, sint fres, sint len, ALN mult_aln, ALNOUT_OPT alnout_opt)
{
	char *seq, residue;
	char val;
	sint n;
	sint i,ii,nseqs;
	sint j,k,slen,cstart,cend;	
	sint start,query_start,query_end;
	sint line_length=60;
	sint max_aln_length,max_names;
	sint color;
	char shape[20];
	char type[20];
	sint nrep,*reptype;

	nseqs=0;
	max_aln_length=max_names=0;
	for(i=0; i<mult_aln.nseqs; i++)  {
                if (mult_aln.seqs[i].output_index>=0) {
			if(mult_aln.seqs[i].len>max_aln_length) max_aln_length=mult_aln.seqs[i].len;
			if(strlen(mult_aln.seqs[i].name)>max_names) max_names=strlen(mult_aln.seqs[i].name);
                        nseqs++;
		}
	}

	seq = (char *)ckalloc((max_aln_length+1) * sizeof(char));

	fprintf(rsfout,"!!RICH_SEQUENCE 1.0\n..\n");

/* set n to the number of sequence groups */
	n=0;
	for(i=0; i<nseqs; i++) 
		if(mult_aln.seqs[i].simgroup>n) n=mult_aln.seqs[i].simgroup;
	n++;

	for(ii=0; ii<nseqs; ii++) {
		i = get_seq_with_index(mult_aln.seqs,mult_aln.nseqs,ii);
		fprintf(rsfout, "{\nname ");
		if(alnout_opt.output_names==1)
			fprintf(rsfout, "%s\n", mult_aln.seqs[i].nid);
		else if(alnout_opt.output_names==2)
			fprintf(rsfout, "%s\n", mult_aln.seqs[i].access);
		else
			fprintf(rsfout, "%s\n", mult_aln.seqs[i].name);
		fprintf(rsfout, "descrip %s\n", mult_aln.seqs[i].title);
		fprintf(rsfout, "creator %s\n", mult_aln.seqs[i].org);
		fprintf(rsfout, "type    ");
		fprintf(rsfout, mult_aln.dnaflag ? "DNA" : "PROTEIN");
		fprintf(rsfout, "\n");
		if(mult_aln.seqs[i].simgroup>0) 
			fprintf(rsfout, "group %d\n",mult_aln.seqs[i].simgroup);
		else {
			fprintf(rsfout, "group %d\n",n);
		}
		for(j=0;j<MAXFTTYPE;j++) {
			for(k=0;k<mult_aln.ft[i].nentries[j];k++) {
				if(mult_aln.ft[i].data[j][k].start<0) continue;
				pos2col(mult_aln.seqs[i].data,mult_aln.ft[i].data[j][k].start,mult_aln.ft[i].data[j][k].end,&cstart,&cend);
				color=-1;
				if(strcmp(mult_aln.ft[i].data[j][k].type,"BLOCK")==0) {
					if (strcmp(mult_aln.ft[i].data[j][k].name,"SBLOCK")==0) {
						color=mult_aln.ft[i].data[j][k].color;
						if(color>15) color=15;
					}
					else if (strcmp(mult_aln.ft[i].data[j][k].name,"LBLOCK")==0) {
						strcpy(mult_aln.ft[i].data[j][k].type,"LOCAL");
						color=12;
					}
				}
				else if(strcmp(mult_aln.ft[i].data[j][k].type,"REGION")==0) {
					color=10;
				}
				else if(strcmp(mult_aln.ft[i].data[j][k].type,"SEQERR")==0) {
					color=3;
				}
				else if(strcmp(mult_aln.ft[i].data[j][k].type,"TRANSMEM")==0) {
					if(strncmp(mult_aln.ft[i].data[j][k].name,"PRED_",5)==0) {
						sprintf(mult_aln.ft[i].data[j][k].name,"%s %.2f",mult_aln.ft[i].data[j][k].name,mult_aln.ft[i].data[j][k].score);
						color=10;
					}
					else if(strncmp(mult_aln.ft[i].data[j][k].name,"PROP_",5)==0) color=11;
					else color=7;
				}
				else if(strcmp(mult_aln.ft[i].data[j][k].type,"COIL")==0) {
					if(strncmp(mult_aln.ft[i].data[j][k].name,"PRED_",5)==0) color=10;
					else if(strncmp(mult_aln.ft[i].data[j][k].name,"PROP_",5)==0) color=11;
					else color=6;
				}
				else if(strcmp(mult_aln.ft[i].data[j][k].type,"LOWCOMP")==0) {
					if(strncmp(mult_aln.ft[i].data[j][k].name,"PRED_",5)==0) color=5;
					else if(strncmp(mult_aln.ft[i].data[j][k].name,"PROP_",5)==0) color=11;
					else color=6;
				}
				else if(strcmp(mult_aln.ft[i].data[j][k].type,"SIGNAL")==0) {
					if(strncmp(mult_aln.ft[i].data[j][k].name,"PRED_",5)==0) {
						sprintf(mult_aln.ft[i].data[j][k].name,"%s %.2f",mult_aln.ft[i].data[j][k].name,mult_aln.ft[i].data[j][k].score);
						color=10;
					}
					else if(strncmp(mult_aln.ft[i].data[j][k].name,"PROP_",5)==0) color=11;
					else color=4;
				}
				if(color>=0) {
				fprintf(rsfout, "feature %d %d %d %s %s %s %.2f\n",cstart+1,cend+1,
										color,
										"square",
										"solid",
										mult_aln.ft[i].data[j][k].type,
										mult_aln.ft[i].data[j][k].score);
				fprintf(rsfout,"  FT   %-10s%5d  %5d  %s\n",
								mult_aln.ft[i].data[j][k].type,
								mult_aln.ft[i].data[j][k].start+1,
								mult_aln.ft[i].data[j][k].end+1,
								mult_aln.ft[i].data[j][k].name);
				}
			}
		}

		slen = 0;
		for(j=fres; j<fres+len; j++) {
			val = mult_aln.seqs[i].data[j];
			if(val==EOS)
				break;
			else if(!isalpha(val))
				residue = '.';
			else {
				residue = val;
			}
			seq[j-fres] = (char)toupper((int)residue);
			slen++;
		}
		fprintf(rsfout,"sequence\n  ");
		for(j=0; j<slen; j++) {
			fprintf(rsfout,"%c",seq[j]);
			if( (j == slen-1)) 
				fprintf(rsfout,"\n");
			else if(( j!=0 && (j+1) % line_length == 0)) 
				fprintf(rsfout,"\n  ");
		}
		fprintf(rsfout,"}\n");
	}	

	seq=ckfree((void *)seq);
}

void tfa_out(FILE *tfaout, sint fres, sint len,ALN mult_aln)
{
	char *seq, residue;
	char val;
	sint i,ii;
	sint j,slen;	
	sint line_length;
	sint max_aln_length,max_names,nseqs;

	nseqs=0;
	max_aln_length=max_names=0;
	for(i=0; i<mult_aln.nseqs; i++)  {
		if(mult_aln.seqs[i].output_index>=0) {
			if(mult_aln.seqs[i].len>max_aln_length) max_aln_length=mult_aln.seqs[i].len;
			if(strlen(mult_aln.seqs[i].name)>max_names) max_names=strlen(mult_aln.seqs[i].name);
			nseqs++;
		}
	}

	seq = (char *)ckalloc((max_aln_length+1) * sizeof(char));

/* decide the line length for this alignment - maximum is LINELENGTH */
	line_length=PAGEWIDTH-max_names;
	line_length=line_length-line_length % 10; /* round to a multiple of 10*/
	if (line_length > LINELENGTH) line_length=LINELENGTH;

	for(ii=0; ii<nseqs; ii++) {
		i = get_seq_with_index(mult_aln.seqs,mult_aln.nseqs,ii);
		fprintf(tfaout, ">");
		fprintf(tfaout, "%s\n", mult_aln.seqs[i].name);
		slen = 0;
		for(j=fres; j<fres+len; j++) {
			val = mult_aln.seqs[i].data[j];
			if(val==EOS)
				break;
			else if(!isalpha(val))
				residue = '-';
			else {
				residue = val;
			}
			seq[j-fres] = (char)toupper((int)residue);
			slen++;
		}
		for(j=0; j<slen; j++) {
			fprintf(tfaout,"%c",seq[j]);
			if(( j!=0 && (j+1) % line_length == 0) || (j == slen-1)) 
				fprintf(tfaout,"\n");
		}
	}	

	seq=ckfree((void *)seq);
}



static int SeqGCGCheckSum(char *seq, int len)
{
	int  i;
        long check;
        
        for( i=0, check=0; i< len; i++,seq++)
                check += ((i % 57)+1) * toupper(*seq);

        return(check % 10000);
}


