#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include "leon.h"

#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))

typedef struct {		/* local core blocks */
        sint first_col;
        sint last_col;
	sint code;
} LCBLOCK,*LCBLOCKPTR;

typedef struct {		/* shared core blocks between 2 groups*/
        sint first_col;
        sint last_col;
	sint group1;
	sint group2;
	sint score;
} SCBLOCK,*SCBLOCKPTR;

typedef struct {		/* shared core blocks grouped into clusters*/
        sint first_col;
        sint last_col;
	sint code;
	sint ngroups;
	sint *group;
	sint *score;
} CCBLOCK,*CCBLOCKPTR;

typedef struct {
        sint first_col;
        sint last_col;
        sint first_res;
        sint last_res;
} SEQERR,*SEQERR_PTR;

static void count_blocks(char *filename,sint ngroups,sint *nscblocks);
static void read_blocks(ALNPTR mult_aln,char *filename,sint ngroups,SCBLOCK *scblocks,sint *seq_weight);
static void count_seqerrs(char *filename,ALNPTR mult_aln,sint *nseqerrs);
static void read_seqerrs(char *filename,ALNPTR mult_aln,sint *nseqerrs,SEQERR **seqerrs,sint *is,sint *ie);
static float countid2(SEQ s1,SEQ s2);
static void add_ft_entry(ALNPTR mult_aln,sint seq,sint first,sint last,sint type,sint code,float score,char *ctype,char *name,sint is,sint ie);
static Boolean check_low_complexity(ALNPTR mult_aln,sint seq,sint first,sint last);

extern sint    gon250mt[];
COMP_MATRIX matrix;

int main(int argc,char **argv)
{
	sint i,ii,j,jj,k,kk,l,s,e,n,g,seq;
	sint t;
	sint seq1;
	char infile[FILENAMELEN+1];
	char treefile[FILENAMELEN+1];
	char blockfile[FILENAMELEN+1];
	char seqerrfile[FILENAMELEN+1];
	char outfile[FILENAMELEN+1];
	char query_name[MAXNAMES+1];
	char type[11];
	ALN mult_aln;
	OPT opt;
	sint nseqs,olen,len,ngroups,nsecgroups;
	GROUP *groups;
	sint *secgroup;
	sint *orggroup;
	sint *seq_weight;
	double dscore,**tgroupmat;
	sint *is, *ie;
	sint status;
	float querymeanpcid;
	float meanpcid;
	char name[MAXNAMES+1];
	sint nscblocks;
	sint nccblocks;
	sint *nseqerrs;
	SEQERR **seqerrs;
	SCBLOCK *scblocks;
	CCBLOCK *ccblocks;
	char c;
        sint    **scb;
	sint *bestgroup;
	sint maxscb;
	sint query_seq,query_group;
	sint score;
	Boolean found;
	Boolean found1,found2;
	Boolean lowc;
	double **tmat;
	sint maxres,*gapptr=NULL;
	PROF queryprofile1,queryprofile2;
	PROF profile1,profile2;




	if(argc!=6) {
		fprintf(stdout,"Usage: %s input_aln block_file seqerr_file query_seq output_aln\n",argv[0]);
		exit(1);
	}
	strcpy(infile,argv[1]);
	strcpy(blockfile,argv[2]);
	strcpy(seqerrfile,argv[3]);
	strcpy(query_name,argv[4]);
	strcpy(outfile,argv[5]);

        init_options(&opt);

	(*opt.alnout_opt).output_clustal=FALSE;
	(*opt.alnout_opt).output_rsf=TRUE;

/* read in the sequences */
	seq_input(infile,opt.explicit_type,FALSE,&mult_aln);
	if(mult_aln.nseqs<=0) {
		error("No sequences in %s\n",infile);
		exit(1);
	}
	nseqs=mult_aln.nseqs;

/* find the query sequence */
        query_seq=(-1);
        for(i=0;i<nseqs;i++) {
                if(strcasecmp(query_name,mult_aln.seqs[i].name)==0) query_seq=i;
        }
        if(query_seq==-1) {
                fprintf(stdout,"Error: the specified reference sequence (%s) was not found in the alignment\n",query_name);
                exit(1);
        }

/* find the start and end positions of each sequence */

        is = (sint *)ckalloc((mult_aln.nseqs+1) * sizeof(sint));
        ie = (sint *)ckalloc((mult_aln.nseqs+1) * sizeof(sint));
        for(s=0;s<mult_aln.nseqs;s++) {
                is[s]=0;
                ie[s] = mult_aln.seqs[s].len-1;
                for (i=0; i<mult_aln.seqs[s].len; i++) {
                        c = mult_aln.seqs[s].data[i];
                        if (!isalpha(c))
                                is[s]++;
                        else
                                break;
                }
                for (i=mult_aln.seqs[s].len-1; i>=0; i--) {
                        c = mult_aln.seqs[s].data[i];
                        if (!isalpha(c))
                                ie[s]--;
                        else
                                break;
                }
        }

/* count pairwise residue percent identities */
        tmat = (double **) ckalloc( (mult_aln.nseqs+1) * sizeof (double *) );
        for(i=0;i<mult_aln.nseqs;i++)
                tmat[i] = (double *)ckalloc( (mult_aln.nseqs+1) * sizeof (double) );

        for (i=0;i<mult_aln.nseqs;i++) {
                for (j=i+1;j<mult_aln.nseqs;j++) {
                        dscore = countid2(mult_aln.seqs[i],mult_aln.seqs[j]);
                        tmat[j][i] = tmat[i][j] = (100.0 - dscore)/100.0;
                }
        }

/* read in the groups */
	secgroup=(sint *)ckalloc((nseqs+1)*sizeof(sint));
	orggroup=(sint *)ckalloc((nseqs+1)*sizeof(sint));

	ngroups=get_groups(blockfile,&mult_aln,secgroup,orggroup);
	if(ngroups<=0) exit(1);

	query_group=secgroup[query_seq]-1;

	groups=(GROUP *)ckalloc((ngroups+2) * sizeof(GROUP));
	for(i=0;i<ngroups;i++) 
		groups[i].seqs=(sint *)ckalloc((mult_aln.nseqs+1) * sizeof(sint));

	for(i=0;i<mult_aln.nseqs;i++) {
		mult_aln.seqs[i].simgroup=secgroup[i];
		groups[secgroup[i]-1].seqs[groups[secgroup[i]-1].len]=i;
		groups[secgroup[i]-1].len++;
	}
	nsecgroups=0;
	for(i=0;i<ngroups;i++) 
		if(groups[i].len>1) nsecgroups++;

/* read in the sequence errors */
        nseqerrs=(sint *)ckalloc((mult_aln.nseqs+1) * sizeof(sint));
        count_seqerrs(seqerrfile,&mult_aln,nseqerrs);
	seqerrs=(SEQERR **)ckalloc((mult_aln.nseqs+1) * sizeof(SEQERR *));
	for(i=0;i<mult_aln.nseqs;i++)
		seqerrs[i]=(SEQERR *)ckalloc((nseqerrs[i]+1) * sizeof(SEQERR));
	read_seqerrs(seqerrfile,&mult_aln,nseqerrs,seqerrs,is,ie);

/* read in the core blocks */
        count_blocks(blockfile,ngroups,&nscblocks);
        scblocks=(SCBLOCK *)ckalloc((nscblocks+1) * sizeof(SCBLOCK));
        ccblocks=(CCBLOCK *)ckalloc((nscblocks+1) * sizeof(CCBLOCK));
	seq_weight=(sint *)ckalloc((mult_aln.nseqs+1) * sizeof(sint));
	read_blocks(&mult_aln,blockfile,ngroups,scblocks,seq_weight);

/* group shared core blocks into overlapping regions */
	n=0;
	for(t=0;t<2;t++) {
	for(i=0;i<nscblocks;i++) {
		found=FALSE;
		for(j=0;j<n;j++) {
			found1=found2=FALSE;
			len=MAX(scblocks[i].last_col-scblocks[i].first_col,ccblocks[j].last_col-ccblocks[j].first_col);
			if ((olen=overlap(scblocks[i].first_col,scblocks[i].last_col,ccblocks[j].first_col,ccblocks[j].last_col))>=len/2) {
				if (ccblocks[j].group[scblocks[i].group1-1]==1) {
					s=MAX(scblocks[i].first_col,ccblocks[j].first_col);
					e=MIN(scblocks[i].last_col,ccblocks[j].last_col);
					g=scblocks[i].group2;
					found1=TRUE;
					found=TRUE;
				}
				if (ccblocks[j].group[scblocks[i].group2-1]==1) {
					s=MAX(scblocks[i].first_col,ccblocks[j].first_col);
					e=MIN(scblocks[i].last_col,ccblocks[j].last_col);
					g=scblocks[i].group1;
					found2=TRUE;
					found=TRUE;
				}
				if((found1==TRUE && found2==FALSE) || (found2==TRUE && found1==FALSE)) {
						if(groups[g-1].len>1) {
							ccblocks[j].first_col=s;
							ccblocks[j].last_col=e;
						}
						ccblocks[j].group[g-1]=1;
						ccblocks[j].score[g-1]=scblocks[i].score;
						ccblocks[j].ngroups++;
				} 
			}
		}
		if(found==FALSE) {
			len=scblocks[i].last_col-scblocks[i].first_col;
			ccblocks[n].code=scblocks[i].group1;
			ccblocks[n].first_col=scblocks[i].first_col;
			ccblocks[n].last_col=scblocks[i].last_col;
			ccblocks[n].group=(sint *)ckalloc((ngroups+1)*sizeof(sint));
			ccblocks[n].score=(sint *)ckalloc((ngroups+1)*sizeof(sint));
			ccblocks[n].group[scblocks[i].group1-1]=1;
			ccblocks[n].score[scblocks[i].group1-1]=scblocks[i].score;
			ccblocks[n].group[scblocks[i].group2-1]=1;
			ccblocks[n].score[scblocks[i].group2-1]=scblocks[i].score;
			ccblocks[n].ngroups=2;
			n++;
		}
	}
	}
	nccblocks=n;

/* check for overlapping regions that need to be merged */
	for(i=0;i<nccblocks;i++) {
		if(ccblocks[i].ngroups==0) continue;
		for(j=i+1;j<nccblocks;j++) {
			if(overlap(ccblocks[i].first_col,ccblocks[i].last_col,ccblocks[j].first_col,ccblocks[j].last_col)>=4) {
				found=FALSE;
				for(k=0;k<ngroups;k++) {
					if(ccblocks[i].group[k]==1 && ccblocks[j].group[k]==1) {
							found=TRUE;
							break;
						}
				}
				if(found==TRUE) {
					for(k=0;k<ngroups;k++) {
						if(ccblocks[i].group[k]==0 && ccblocks[j].group[k]==1) {
							ccblocks[i].group[k]=1;
							ccblocks[j].group[k]=0;
							ccblocks[i].ngroups++;
						}
					}
					ccblocks[j].ngroups=0;
				}
			}
		}
	}

/* re-score all core blocks against the query */
	matrix.format=0;
        maxres = get_cl_matrix(FALSE, gon250mt, gapptr, TRUE, 100, &matrix);

       	querymeanpcid=0;
       	for(k=0,n=0;k<groups[query_group].len;k++)
               	for(l=k;l<groups[query_group].len;l++) {
                       	querymeanpcid+=(1.0-tmat[groups[query_group].seqs[k]][groups[query_group].seqs[l]]);
                       	n++;
               	}
       	querymeanpcid/=(float)n;

	for(i=0;i<nccblocks;i++) {
		if(ccblocks[i].ngroups==0) continue;
		if(ccblocks[i].group[query_group]==0) continue;
		len=ccblocks[i].last_col-ccblocks[i].first_col;
		queryprofile1.data = (sint **) ckalloc( (len+2) * sizeof (sint *) );
		for(k=0; k<len+2; k++)
			queryprofile1.data[k] = (sint *) ckalloc( (LENCOL+2) * sizeof(sint) );
		calc_blockprf1(mult_aln,seq_weight,ccblocks[i].first_col,ccblocks[i].last_col-1,
                                groups[query_group],matrix,is,ie,&queryprofile1,querymeanpcid);
		queryprofile2.data = (sint **) ckalloc( (len+2) * sizeof (sint *) );
		for(k=0; k<len+2; k++)
			queryprofile2.data[k] = (sint *) ckalloc( (LENCOL+2) * sizeof(sint) );
		calc_blockprf2(mult_aln,seq_weight,ccblocks[i].first_col,ccblocks[i].last_col-1,
                                groups[query_group],is,ie,&queryprofile2);
                        
		for(j=0;j<ngroups;j++) {
			if(ccblocks[i].group[j]==1) {
				if(groups[j].len>1) {
       					meanpcid=0;
       					for(k=0,n=0;k<groups[j].len;k++)
               					for(l=k;l<groups[j].len;l++) {
                       					meanpcid+=(1.0-tmat[groups[j].seqs[k]][groups[j].seqs[l]]);
                       					n++;
               					}
       					meanpcid/=(float)n;
					profile1.data = (sint **) ckalloc( (len+2) * sizeof (sint *) );
					for(k=0; k<len+2; k++)
						profile1.data[k] = (sint *) ckalloc( (LENCOL+2) * sizeof(sint) );
					calc_blockprf1(mult_aln,seq_weight,ccblocks[i].first_col,ccblocks[i].last_col-1,
                                		groups[j],matrix,is,ie,&profile1,meanpcid);
					profile2.data = (sint **) ckalloc( (len+2) * sizeof (sint *) );
					for(k=0; k<len+2; k++)
						profile2.data[k] = (sint *) ckalloc( (LENCOL+2) * sizeof(sint) );
					calc_blockprf2(mult_aln,seq_weight,ccblocks[i].first_col,ccblocks[i].last_col-1,
                                		groups[j],is,ie,&profile2);
					score=score_block_vs_block(ccblocks[i].first_col,ccblocks[i].first_col,queryprofile1,profile2);
					for(k=0; k<len+2; k++)
                        			ckfree(profile1.data[k]);
                			ckfree(profile1.data);
					for(k=0; k<len+2; k++)
                        			ckfree(profile2.data[k]);
                			ckfree(profile2.data);
				}
				else
					score=score_sequence(mult_aln.seqs[groups[j].seqs[0]].data,queryprofile1,ccblocks[i].first_col,ccblocks[i].last_col);
				ccblocks[i].score[j]=score;
			}
		}
		for(k=0; k<len+2; k++)
			ckfree(queryprofile1.data[k]);
		ckfree(queryprofile1.data);
		for(k=0; k<len+2; k++)
			ckfree(queryprofile2.data[k]);
		ckfree(queryprofile2.data);
	}

/* check for sequence errors */
	for(i=0;i<nccblocks;i++) {
		if(ccblocks[i].ngroups==0) continue;
		for(j=0;j<ngroups;j++)
			if(ccblocks[i].group[j]==1 && ccblocks[i].score[j]>0) {
				for(k=0;k<groups[j].len;k++) {
					seq=groups[j].seqs[k];
					found=0;
					for(l=0;l<nseqerrs[seq];l++)
						if(overlap(ccblocks[i].first_col,ccblocks[i].last_col,seqerrs[seq][l].first_col,seqerrs[seq][l].last_col)>=(ccblocks[i].last_col-ccblocks[i].first_col)/2.0) {
							found=TRUE;
							break;
						}
					if(found==FALSE) {
						score=ccblocks[i].score[j];
/* check also for low complexity regions */
						lowc=check_low_complexity(&mult_aln,query_seq,ccblocks[i].first_col,ccblocks[i].last_col);
						if(lowc==FALSE)
							lowc=check_low_complexity(&mult_aln,seq,ccblocks[i].first_col,ccblocks[i].last_col);
						if(mult_aln.seqs[query_seq].hydrophobicity>2.25) {
							score/=mult_aln.seqs[query_seq].hydrophobicity;
						}
						else if(mult_aln.seqs[seq].hydrophobicity>2.25) {
							score/=mult_aln.seqs[seq].hydrophobicity;
						}
						else if(lowc) {
							score/=1.5;
						}
						add_ft_entry(&mult_aln,seq,ccblocks[i].first_col,ccblocks[i].last_col,COREBLOCK,ccblocks[i].code,(float)score/10000.0,"BLOCK","SBLOCK",is[seq],ie[seq]);
					}
				}
			}
	}


	for(i=0;i<mult_aln.nseqs;i++)
		for(j=0;j<nseqerrs[i];j++) {
			add_ft_entry(&mult_aln,i,seqerrs[i][j].first_col,seqerrs[i][j].last_col,SEQERRBLOCK,0,0.0,"SEQERR","SEQERR",is[i],ie[i]);
		}

/* for each orphan or orphan group, find the closest group */
	scb=(sint **)ckalloc((ngroups+1)*sizeof(sint *));
	for(i=0;i<ngroups;i++)
		scb[i]=(sint *)ckalloc((ngroups+1)*sizeof(sint));
		
	for(i=0;i<nscblocks;i++) {
		scb[scblocks[i].group1-1][scblocks[i].group2-1]++;
		scb[scblocks[i].group2-1][scblocks[i].group1-1]++;
	}
	bestgroup=(sint *)ckalloc((ngroups+1)*sizeof(sint));
	for (i=0;i<ngroups;i++) {
		bestgroup[i]=0;
		maxscb=0;
		for (j=0;j<ngroups;j++) {
			if(scb[i][j]>maxscb) {
				maxscb=scb[i][j];
				bestgroup[i]=j+1;
			}
		}
	}

	ckfree(scblocks);

/* set the output order of the groups */
/* first list secator groups and any orphans that match the group */
/* then look for any groups that are left over */
        for (i=0;i<mult_aln.nseqs;i++)
                mult_aln.seqs[i].output_index = -1;

        for (i=0;i<ngroups;i++) {
		if(groups[i].len>1 && secgroup[groups[i].seqs[0]]==orggroup[groups[i].seqs[0]]) {
			for(j=0;j<ngroups;j++) {
                		if((groups[j].len>0) && (groups[j].len==1 || secgroup[groups[j].seqs[0]]!=orggroup[groups[j].seqs[0]])) 
					if(bestgroup[j]==i+1) {
						for(k=0;k<groups[j].len;k++) {
							mult_aln.seqs[groups[j].seqs[k]].simgroup=i+1;
						}
					}
			}
		}
        }

        for (i=0;i<ngroups;i++)
		if(groups[i].len>1) {
			for(j=0;j<ngroups;j++) {
                		if(groups[j].len==1 && bestgroup[j]==i+1) 
					for(k=0;k<groups[j].len;k++) {
						mult_aln.seqs[groups[j].seqs[k]].simgroup=i+1;
					}
			}
		}

	n=0;
	for (j=0;j<ngroups;j++)
		for(i=0;i<mult_aln.nseqs;i++) 
			if(mult_aln.seqs[i].simgroup==j+1) {
				mult_aln.seqs[i].output_index=n++;
			}

        for (i=0;i<ngroups;i++)
                for(j=0;j<groups[i].len;j++) {
                        if(mult_aln.seqs[groups[i].seqs[j]].output_index == (-1)) {
                                mult_aln.seqs[groups[i].seqs[j]].output_index = n++;
                                if(groups[i].len==1) mult_aln.seqs[groups[i].seqs[j]].simgroup=0;
                        }
                }


/* write out the sequences */
	strcpy((*opt.alnout_opt).rsf_outname, outfile);

	if(!open_alignment_output(infile,opt.alnout_opt)) exit(1);
        create_alignment_output(mult_aln,*opt.alnout_opt,*opt.ss_opt);
}

static Boolean check_low_complexity(ALNPTR mult_aln,sint seq,sint first,sint last)
{
	sint fr,lr;
	sint i,j,l;

	col2pos(mult_aln->seqs[seq].data,first,last,&fr,&lr);

	for(i=0;i<MAXFT;i++) {
		if(i==TRANSMEM || i==COIL || i==LOWC) {
			for(j=0;j<mult_aln->ft[seq].nentries[i];j++) {
				if((l=overlap(fr,lr,mult_aln->ft[seq].data[i][j].start,mult_aln->ft[seq].data[i][j].end))>4) {
					return TRUE;
				}
			}
		}
	}

	return FALSE;
}

static void add_ft_entry(ALNPTR mult_aln,sint seq,sint first,sint last,sint type,sint code,float score,char *ctype,char *name,sint is,sint ie)
{
        sint n;
	sint fr,lr;
	sint fc,lc;

	if(mult_aln->ft[seq].nentries[type]>MAXFT) {
		fprintf(stdout,"WARNING: too many features in %s %d (%d)\n",mult_aln->seqs[seq].name,mult_aln->ft[seq].nentries[type],type);
		return;
	}
	if(last<is || first>ie) return;
	if(first<is) first=is;
	if(last>ie) last=ie;
        n=mult_aln->ft[seq].nentries[type];
        alloc_ft_entry(&mult_aln->ft[seq].data[type][n]);
        strcpy(mult_aln->ft[seq].data[type][n].type,ctype);
	col2pos(mult_aln->seqs[seq].data,first,last,&fr,&lr);
	pos2col(mult_aln->seqs[seq].data,fr,lr,&fc,&lc);
	if(fc==first)
        	mult_aln->ft[seq].data[type][n].start=fr;
	else
		mult_aln->ft[seq].data[type][n].start=fr+1;
	if(lc==last)
        	mult_aln->ft[seq].data[type][n].end=lr;
	else
		mult_aln->ft[seq].data[type][n].end=lr-1;
        strcpy(mult_aln->ft[seq].data[type][n].name,name);
        mult_aln->ft[seq].data[type][n].color=code;
	mult_aln->ft[seq].data[type][n].score=score;
        mult_aln->ft[seq].nentries[type]++;

}

static void count_seqerrs(char *filename,ALNPTR mult_aln,sint *nseqerrs)
{
        FILE *fin;
        char line[MAXLINE+1];
        int i,f,l,t;
        char tmp[MAXLINE+1];
        char name[MAXLINE+1];

        if((fin=fopen(filename,"r"))==NULL) {
                error("Could not open seqerr file %s",filename);
                return;
        }
	for(i=0;i<mult_aln->nseqs;i++)
        	nseqerrs[i]=0;
        while(fgets(line,MAXLINE+1,fin)) {
                if(keyword(line,"SEQ_ERROR")) {
                        sscanf(line,"%s %d %s %d %d\n",tmp,&t,name,&f,&l);
			for(i=0;i<mult_aln->nseqs;i++) {
				if(strcmp(mult_aln->seqs[i].name,name)==0) {
					if(f<l) nseqerrs[i]++;
				}
			}
                }
        }

        fclose(fin);

}

static void read_seqerrs(char *filename,ALNPTR mult_aln,sint *nseqerrs,SEQERR **seqerrs,sint *is,sint *ie)
{
        FILE *fin;
        char line[MAXLINE+1];
        int i,f,l;
        char tmp[MAXLINE+1];
        char name[MAXLINE+1];

        if((fin=fopen(filename,"r"))==NULL) {
                error("Could not open block file %s",filename);
                return;
        }
	for(i=0;i<mult_aln->nseqs;i++)
        	nseqerrs[i]=0;
        while(fgets(line,MAXLINE+1,fin)) {
                if(keyword(line,"SEQ_ERROR")) {
                        sscanf(line,"%s %d %s %d %d\n",tmp,&i,name,&f,&l);
			for(i=0;i<mult_aln->nseqs;i++) {
				if(strcmp(mult_aln->seqs[i].name,name)==0) {
					if(f<l) {
						if(f<is[i]+1) f=is[i]+1;
						if(l>ie[i]+1) l=ie[i]+1;
						seqerrs[i][nseqerrs[i]].first_col=f-1;
						seqerrs[i][nseqerrs[i]].last_col=l-1;
						col2pos(mult_aln->seqs[i].data,seqerrs[i][nseqerrs[i]].first_col,seqerrs[i][nseqerrs[i]].last_col,&seqerrs[i][nseqerrs[i]].first_res,&seqerrs[i][nseqerrs[i]].last_res);
						nseqerrs[i]++;
					}
				}
			}
                }
        }

        fclose(fin);
}
static void count_blocks(char *filename,sint ngroups,sint *nscblocks)
{
        FILE *fin;
        char line[MAXLINE+1];
        int i,f,l,code,group,g;
        int group1,group2,score;
        char tmp[MAXLINE+1];

        if((fin=fopen(filename,"r"))==NULL) {
                error("Could not open block file %s",filename);
                return;
        }

        (*nscblocks)=0;
        while(fgets(line,MAXLINE+1,fin)) {
                if(keyword(line,"SHAREDCOREBLOCK")) {
                        sscanf(line,"%s %d %d %d %d %d\n",tmp,&group1,&group2,&f,&l,&score);
                        if(f<l && group1 != group2) 
                        	(*nscblocks)++;
                }
        }

        fclose(fin);

}

static void read_blocks(ALNPTR mult_aln,char *filename,sint ngroups,SCBLOCK *scblocks,sint *seq_weight)
{
        FILE *fin;
        char line[MAXLINE+1];
        int i,f,l,code,group,g;
        int group1,group2,score;
        char tmp[MAXLINE+1];
	char name[MAXNAMES+1];
	int nscblocks;

        if((fin=fopen(filename,"r"))==NULL) {
                error("Could not open block file %s",filename);
                return;
        }
        nscblocks=0;
        while(fgets(line,MAXLINE+1,fin)) {
                if(keyword(line,"SHAREDCOREBLOCK")) {
                        sscanf(line,"%s %d %d %d %d %d\n",tmp,&group1,&group2,&f,&l,&score);
                        if(f<l && group1 != group2) {
                                scblocks[nscblocks].group1=group1;
                                scblocks[nscblocks].group2=group2;
                                scblocks[nscblocks].first_col=f-1;
                                scblocks[nscblocks].last_col=l-1;
                                scblocks[nscblocks].score=score;
                                nscblocks++;
                        }
                }
		else if (keyword(line,"SEQWEIGHT")) {
			sscanf(line,"%s %s %d\n",tmp,name,&f);
			for(i=0;i<mult_aln->nseqs;i++) {
				if(strcasecmp(mult_aln->seqs[i].name,name)==0) {
					seq_weight[i]=f;
					break;
				}
			}
		}
        }

        fclose(fin);
}

static float countid2(SEQ s1,SEQ s2)
{
   sint i,j;
   sint count,len,pcid;
   sint window=20;
   float score;
   char *seq1,*seq2;

/* remove gap positions from alignment of 2 sequences */
   seq1=(char *)ckalloc((s1.len+1)*sizeof(char));
   seq2=(char *)ckalloc((s2.len+1)*sizeof(char));
   for(i=0,len=0;i<s1.len && i<s2.len;i++) {
     if(isalpha(s1.data[i])||isalpha(s2.data[i])) {
         seq1[len]=s1.data[i];
         seq2[len]=s2.data[i];
         len++;
     }
   }

/* calculate number of identities in a fixed window length along alignment and
count number of times identity is greater than a threshold */
   count = 0;
   for (i=window;i<len-window;i++) {
       pcid=0;
       for(j=i-window;j<i+window;j++) {
         if(seq1[j]==seq2[j]) {
                   pcid++;
         }
       }
       if(pcid>0.4*(float)window*2.0) count++;
   }
   if(len-window*2.0<=0) score=0;
   else score=(float)(100.0 * (float)count/(float)(len-window*2.0));

   ckfree(seq1);
   ckfree(seq2);

   return score;
}

