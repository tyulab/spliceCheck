#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "leon.h"

static int read_coils(FILE *fd,ALN mult_aln);

/* global data */

Boolean verbose;

int main(int argc, char **argv)
{
	FILE *tfd,*ifd,*ofd;
	char c;
	sint  i,j,jj,k,kk,n,n1,seq,seq1;
	sint s,e,type;
	sint err,ix;
	Boolean eof,found;
        char infile[FILENAMELEN+1];
        char coilsfile[FILENAMELEN+1];
        char clusterfile[FILENAMELEN+1];
        char outfile[FILENAMELEN+1];
        sint    *secgroup;
        sint    *orggroup;
	sint *is, *ie;
        sint ngroups;
	float maxscore;
        GROUP *groups;
	ALN mult_aln;
        double dscore,**tmat;
	OPT opt;

	if(argc!=5) {
		fprintf(stderr,"Usage: %s aln_file coils_file cluster_file out_file\n",argv[0]);
		return 1;
	}
        strcpy(infile,argv[1]);
        strcpy(coilsfile,argv[2]);
	strcpy(clusterfile,argv[3]);
        strcpy(outfile,argv[4]);

        init_options(&opt);

/* open the aln file */
        seq_input(infile,opt.explicit_type,FALSE,&mult_aln);

        if(mult_aln.nseqs<=0) exit(1);

/* read the list of coils */
        if((tfd=fopen(coilsfile,"r"))==NULL) {
                error("Could not open coils file %s",coilsfile);
                return -1;      
        }
	read_coils(tfd,mult_aln);

/* count pairwise residue percent identities */
        tmat = (double **) ckalloc( (mult_aln.nseqs+1) * sizeof (double *) );
        for(i=0;i<mult_aln.nseqs;i++)
                tmat[i] = (double *)ckalloc( (mult_aln.nseqs+1) * sizeof (double) );

        for (i=0;i<mult_aln.nseqs;i++) {
                for (j=i+1;j<mult_aln.nseqs;j++) {
                        dscore = countid1(mult_aln.seqs[i],mult_aln.seqs[j]);
                        tmat[j][i] = tmat[i][j] = (100.0 - dscore)/100.0;
                }
        }

/* read in the secator groups */
        groups=(GROUP *)ckalloc((mult_aln.nseqs+2) * sizeof(GROUP));
        secgroup=(sint *)ckalloc((mult_aln.nseqs+1)*sizeof(sint));
        orggroup=(sint *)ckalloc((mult_aln.nseqs+1)*sizeof(sint));
        ngroups=read_secator_groups(mult_aln,tmat,clusterfile,groups,secgroup,orggroup,0.4);

/* find the start and end positions of each sequence */

        is = (sint *)ckalloc((mult_aln.nseqs+1) * sizeof(sint));
        ie = (sint *)ckalloc((mult_aln.nseqs+1) * sizeof(sint));
        for(s=0;s<mult_aln.nseqs;s++) {
                is[s]=0;
                ie[s] = mult_aln.seqs[s].len-1;
                for (i=0; i<mult_aln.seqs[s].len; i++) {
                        c = mult_aln.seqs[s].data[i];
                        if (!isalpha(c))
                                is[s]++;
                        else
                                break;
                }
                for (i=mult_aln.seqs[s].len-1; i>=0; i--) {
                        c = mult_aln.seqs[s].data[i];
                        if (!isalpha(c))
                                ie[s]--;
                        else
                                break;
                }
        }

/* write out in rsf format */
        (*opt.alnout_opt).output_clustal=FALSE;
        (*opt.alnout_opt).output_rsf=TRUE;
        strcpy((*opt.alnout_opt).rsf_outname, outfile);
        if(!open_alignment_output(infile,opt.alnout_opt)) exit(1);
        create_alignment_output(mult_aln,*opt.alnout_opt,*opt.ss_opt);

}

static int read_coils(FILE *fd,ALN mult_aln)
{
	int i,k,n=0;
	int fres,lres,color;
	int type;
        char line[MAXLINE+1];
	char name[MAXNAMES];
	char tmp[MAXNAMES];
	float tmscore;
	Boolean found;


        while (fgets(line,MAXLINE+1,fd) != NULL) {
                if(blankline(line)) continue;
		if(isspace(line[0])) continue;
		type=0;
		if(keyword(line,"COIL")) {
			if (sscanf(line," %s %s %d %d ",tmp,name,&fres,&lres)!=4) {
				continue;
			}
			type=COIL;
		} 
		if(type>0) {
			found=FALSE;
			for(i=0;i<mult_aln.nseqs;i++) {
				if(strcmp(name,mult_aln.seqs[i].name)==0) {
					k=mult_aln.ft[i].nentries[type];
					alloc_ft_entry(&mult_aln.ft[i].data[type][k]);
					mult_aln.ft[i].data[type][k].start=fres-1;
					mult_aln.ft[i].data[type][k].end=lres-1;
					mult_aln.ft[i].data[type][k].score=0;
					pos2col(mult_aln.seqs[i].data,mult_aln.ft[i].data[type][k].start,mult_aln.ft[i].data[type][k].end,&mult_aln.ft[i].data[type][k].start_col,&mult_aln.ft[i].data[type][k].end_col);
					if (type==COIL) {
						strcpy(mult_aln.ft[i].data[type][k].type,"COIL");
						strcpy(mult_aln.ft[i].data[type][k].name,"PRED_COIL");
					}
					mult_aln.ft[i].nentries[type]++;
					n++;
					found=TRUE;
					break;
				}
			}
			if(!found) 
				fprintf(stdout,"bad name in coils file: %s\n",line);
		}
        }

	return n;
}


