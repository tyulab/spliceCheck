/*********************************************/
/*                                           */
/*Procedure de calcul des poids des sequences*/
/*                                           */
/*********************************************/

void calcul_poids_sequences(t_noeud *noeud,double poids);

/***************************************************************/
/*                                                             */
/*Procedure de calcul du nombre de feuilles a partir d'un noeud*/
/*                                                             */
/***************************************************************/

void calcul_nombre_feuilles(t_noeud *noeud,int *nb_feuilles);
