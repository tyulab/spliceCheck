/****************************************/
/*                                      */
/*Procedure de tri par ordre decroissant*/
/*                                      */
/****************************************/

void tri_rapide_local(double *valeurs,t_noeud **noeuds,int gauche,int droite);

/*******************************************/
/*                                         */
/*sous-procedure de tri_rapide             */ 
/*                                         */
/*******************************************/

void echanger_local(double *valeurs,t_noeud **noeuds,int element1,int element2);

/*****************************************************************/
/*                                                               */
/*Procedure de classification hierarchique base sur l'arbre bionj*/
/*avec decouverte du nombre de groupes par Secator               */
/*                                                               */
/*****************************************************************/

void secator_bionj(int nb_individus,t_noeud *racine,int *nb_clusters,int weighting,
		   int nb_clusters_selection,int nb_clusters_selected);

/**************************************************/
/*                                                */
/*Procedure de recherche des adresses des feuilles*/
/*                                                */
/**************************************************/

void cherche_adresses_noeuds(t_noeud *noeud,t_noeud **adresses_noeuds);

/**************************************************************/
/*                                                            */
/*Procedure de construction de la solution dans le cas general*/
/*                                                            */
/**************************************************************/

void clusters_building(int nb_individus,double seuil_pertes_inertie,
		       t_noeud *racine,t_noeud **adresses_noeuds);
