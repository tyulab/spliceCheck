#include "principal.h"

/************************************************************/
/*                                                          */
/*Procedure trouvant le seuil de dissimilarite dans un arbre*/
/*                                                          */
/************************************************************/

void tree_threshold_discovery()
{
  /*declaration de variables*/
  /*fin declaration de variables*/
}
