#define FEUILLE 0
#define NOEUD_ORDINAIRE 1

/*********************************************************************************/
/*                                                                               */
/*Procedure de classification hierarchique par la methode des voisins reciproques*/ 
/*                                                                               */
/*********************************************************************************/

void classification_ward(int nb_individus,int nb_dimensions,t_individu **individus,
			 int type_donnees,t_noeud **racine);
