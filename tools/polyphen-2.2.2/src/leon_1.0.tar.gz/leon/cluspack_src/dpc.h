/**************************************************************/
/*                                                            */
/*Procedure de test pour savoir si l'on doit scinder un groupe*/
/*par la methode DPC (Density of Points Clustering)           */ 
/*                                                            */
/**************************************************************/

int test_DPC(int nb_individus,int nb_dimensions,t_groupe *groupe_pere,
	     t_groupe *groupe1,t_groupe *groupe2,double **coordonnees_individus,
	     double *cotes_hyperpave,double *valeurs_minimum,double risque,
	     int type_donnees,int type_densite,int donnees_normalisees,
	     int nb_simulations);
