/****************************************************/
/*                                                  */
/*Procedure de realisation de clustering par k-means*/
/*en partant d'un debut de clustering               */ 
/*                                                  */
/****************************************************/

void kmeans(int nb_individus,int nb_dimensions,t_individu **individus,int nb_classes);

/***************************************************/
/*                                                 */
/*Procedure d'affectation des individus aux groupes*/
/*et de calcul des nouveaux centres de gravite     */
/*                                                 */
/***************************************************/

void affectation_individuskmeans(int nb_dimensions,int nb_individus,int nb_classes,
				 int *nb_individus_par_classe,t_individu **individus,
				 double **centres,double *inertie_intra_classe);
