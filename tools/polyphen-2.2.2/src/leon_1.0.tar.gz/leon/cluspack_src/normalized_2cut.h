/********************************************************************/
/*                                                                  */
/*Procedure de recherche de coupe minimum normalisee de Xing et Karp*/
/*                                                                  */
/********************************************************************/

int normalized_cut(t_groupe *groupe,t_groupe *groupe1,t_groupe *groupe2);


/********************************************************/
/*                                                      */
/*Procedure renvoyant pour un vecteur donne la valeur   */
/*de la fonction objectif associee a la coupe normalisee*/
/*                                                      */
/********************************************************/

double evaluation_coupe_normalisee_minimum(int nb_dimensions,double *y,double *D,double **DminusW);
