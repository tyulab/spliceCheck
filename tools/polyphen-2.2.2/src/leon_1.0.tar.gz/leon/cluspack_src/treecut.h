/*******************************************************************************/
/*                                                                             */
/*Procedure de decouverte du nombre de clusters par Secator a partir d'un arbre*/
/*                                                                             */
/*******************************************************************************/

void secator_tree(int nb_individus,t_noeud *racine,double *seuil_dissimilarite,int *nb_clusters);

/********************************************************/
/*                                                      */
/*Procedure de decoupage de l'arbre en coupant quand la */
/*dissimilarite est superieure au seuil de dissimilarite*/
/*                                                      */
/********************************************************/

void decoupage_arbre_seuil_dissimilarite(int nb_motifs,t_noeud *noeud,double seuil_dissimilarite,
					 int *nb_clusters);

/******************************************************************/
/*                                                                */
/*Procedure de recherche des premiers noeuds valides d'une branche*/
/*i.e les premiers a avoir une perte d'inertie superieur au seuil */
/*                                                                */
/******************************************************************/

void cherche_premiers_noeuds_valides(t_noeud *noeud,double seuil_dissimilarite,
				     int *nb_noeuds_trouves,t_noeud **noeuds_trouves);

/*************************************************************************/
/*                                                                       */
/*Procedure de recherche de toutes les feuilles a partir d'un noeud donne*/
/*                                                                       */
/*************************************************************************/

void cherche_feuilles(t_noeud *noeud,int *nb_feuilles,t_noeud **feuilles);

/**********************************************************************************/
/*                                                                                */
/*Procedure de decouverte du seuil de dissimilarite a partir du nombre de clusters*/
/*                                                                                */
/**********************************************************************************/

void nb_clusters_to_dissimilarity_threshold(int nb_individus,int nb_clusters,t_noeud *racine,
					    double *seuil_dissimilarite);

/*******************************************************************/
/*                                                                 */
/*Procedure recursive de recuperation des dissimilarites d'un arbre*/
/*                                                                 */
/*******************************************************************/

void recupere_dissimilarites(t_noeud *noeud,int *compteur,double *dissimilarites);
