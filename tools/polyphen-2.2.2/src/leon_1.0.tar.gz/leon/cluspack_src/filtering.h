/******************************************/
/*                                        */
/*Procedure de normalisation des individus*/
/*                                        */
/******************************************/

void normalisation_individus(int nb_individus,int nb_dimensions,t_individu **individus);

/**************************************************************/
/*                                                            */
/*Procedure de calcul des similarites a partir des coordonnees*/
/*en utilisant les correlations                               */
/*                                                            */
/**************************************************************/

void coordonnees_to_similarites(int nb_individus,int nb_dimensions,t_individu **individus);

/*********************************************/
/*                                           */
/*Procedure de filtrage des individus suivant*/ 
/*une valeur seuil et le type des donnees    */
/*                                           */
/*********************************************/

void filtre_individus(int *nb_individus,int nb_dimensions,t_individu **individus,
		      int type_donnees,double distance_min);
