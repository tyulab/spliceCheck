#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include "leon.h"

#define WINDOW 11
#define CUTOFF 0.5*WINDOW*(WINDOW+1)
#define MAXTM 100

typedef struct {
        sint start;                     /* first residue */
        sint end;                       /* second residue */
	float score;			/* ges score */
} TMENTRY,*TMENTRYPTR;

void score_aln(ALN mult_aln);
int low_complexity(char *name,char *seq,int len,sint ntm,TMENTRY *tm);
void rescomp(ALN mult_aln,sint *ntm,TMENTRY **tm);
sint get_tm_regions(char *seq,sint len,TMENTRY *tm,sint tmwin,float tm_threshold);

Boolean verbose;

float comp_sd;

float ges_scale[] = {
-1.6, 0.0, -2.0, 9.2, 8.2, -3.7, -1.0, 3.0, -3.1, 0.0, 8.8, -2.8, -3.4, 4.8, 
0.0, 0.2, 4.1, 12.3, -0.6, -1.2, 0.0, -2.6, -1.9, 0.0, 0.7, 0.0};

int main(int argc, char **argv)
{
	FILE *ifd,*tfd,*afd;
	int  err,i,j,k,ires,iseq=0;
	int ix;
	char t[MAXLINE+1];
	char infile[FILENAMELEN+1];
	ALN mult_aln;
	OPT opt;

	if(argc<2) {
		fprintf(stderr,"Usage: %s test_aln [-v]\n",argv[0]);
		fprintf(stderr,"                      test_aln      test alignment in msf format \n");
		fprintf(stderr,"                      -v            verbose mode\n");
		return 1;
	}
	strcpy(infile,argv[1]);

	if(argc>2)
		verbose=TRUE;

/* read the test alignment into mult_aln */
	seq_input(infile,0,FALSE,&mult_aln);

	if(mult_aln.nseqs==0) {
		return 0;
	}

	score_aln(mult_aln);

        fprintf(stdout,"\n");
}


void score_aln(ALN mult_aln)
{
	int i,j,k,len,n;
	char *seq;
	float *score;
        float spscore,maxspscore;
        int *sp_start;
	int *ntm;
	TMENTRY **tm;
	int ntmseqs;
	sint tmwin;
	sint spwin;
	float tm_threshold;

	if(verbose) fprintf(stdout,"\n");
	score=(float *)ckalloc((mult_aln.nseqs+1)*sizeof(float));
        sp_start=(sint *)ckalloc((mult_aln.nseqs+1)*sizeof(sint));
	ntm=(sint *)ckalloc((mult_aln.nseqs+1)*sizeof(sint));
	tm=(TMENTRY **)ckalloc((mult_aln.nseqs+1)*sizeof(TMENTRY *));
	for(i=0;i<mult_aln.nseqs;i++) {
		tm[i]=(TMENTRY *)ckalloc((MAXTM+1)*sizeof(TMENTRY));
	}


	for(i=0;i<mult_aln.nseqs;i++) {
		seq=(char *)ckalloc((mult_aln.seqs[i].len+1)*sizeof(char));

		for(j=0,len=0;j<mult_aln.seqs[i].len;j++)
			if(islower(mult_aln.seqs[i].data[j])) seq[len++]=mult_aln.seqs[i].data[j]-'a';

/* calculate average ges scale over full sequence */
		score[i]=0;
		for(j=0;j<len;j++) {
			score[i]+=ges_scale[seq[j]];
		}
		if(len>0) score[i]/=(float)len;
		else score[i]=0;

/* look for possible tm helices */
		tmwin=15;
		tm_threshold=(-1.0);
		ntm[i]=get_tm_regions(seq,len,tm[i],tmwin,tm_threshold);

/* count the number of high scoring regions */
		n=0;
		for(j=0;j<ntm[i];j++) {
			if(tm[i][j].score>12.0) n++;
		}
/* if no high scores, remove all predicted tm */
		if(n==0) {
			for(j=0;j<ntm[i];j++) {
				tm[i][j].start=(-1);
				ntm[i]=0;
			}
		}
/* if we find only 1 strong region ... */
		else if(n==1) {
			for(j=0;j<ntm[i];j++) 
				if(tm[i][j].score>10.0) break;
		}

/* if we still have some tm regions, recalulate regions with softer thresholds */
		n=0;
		for(j=0;j<ntm[i];j++) 
			if(tm[i][j].start>=0) n++;
			
		if(n>0) {
			tmwin=12;
			tm_threshold=0.0;
			ntm[i]=get_tm_regions(seq,len,tm[i],tmwin,tm_threshold);
			for(j=0;j<ntm[i];j++) {
				if(tm[i][j].start>=0 && tm[i][j].score>0.5)
				fprintf(stdout,"TM %s %d %d %.2f\n",mult_aln.seqs[i].name,tm[i][j].start+1,tm[i][j].end+1,tm[i][j].score);
			}
		}
		ckfree(seq);
	}

	ntmseqs=0;
	for(i=0;i<mult_aln.nseqs;i++)
		if(score[i]<=1.0 && ntm[i]>0) ntmseqs++;

	ckfree(score);

/* check for low complexity regions */
	rescomp(mult_aln,ntm,tm);

}

sint get_tm_regions(char *seq,sint len,TMENTRY *tm,sint tmwin,float tm_threshold)
{
	sint ntm,j;
	Boolean in_bias,lin_bias;
	sint ltmpeak,stmpeak;
	float tmscore;
	float *avw;

/* find tm regions */
	tm_threshold*=(float)tmwin;
	avw=(float *)ckalloc((len+1)*sizeof(float));
	for(j=0;j<len;j++)
		avw[j]=0;
	for(j=0;j<tmwin;j++) {
		avw[tmwin-1]+=ges_scale[seq[j]];
	}
	for(j=tmwin;j<len;j++) {
		avw[j]=avw[j-1]-ges_scale[seq[j-tmwin]]+ges_scale[seq[j]];
		/*if(verbose) fprintf(stdout,"%c %.2f",(char)(seq[j]+'a'),avw[j]);*/
               }
	in_bias=lin_bias=FALSE;
	ltmpeak=stmpeak=0;
	ntm=0;
	for(j=tmwin;j<len;j++) {
		if(avw[j]<tm_threshold) {
			in_bias=TRUE;
			tmscore+=avw[j];
			if(lin_bias==FALSE) {
				stmpeak=j-tmwin*0.5;
				tmscore=0.0;
			}
		}
		else {
			if(lin_bias==TRUE && j>=stmpeak+tmwin) {
				ltmpeak=j;
				tm[ntm].start=stmpeak;
				tm[ntm].end=ltmpeak;
				tm[ntm].score=-tmscore/(float)(tm[ntm].end-tm[ntm].start);
				ntm++;
			}
			in_bias=FALSE;
		}
		lin_bias=in_bias;
        }

	if(lin_bias==TRUE && j>=stmpeak+tmwin) {
		ltmpeak=j;
		tm[ntm].start=stmpeak;
		tm[ntm].end=ltmpeak;
		tm[ntm].score=-tmscore/(float)(tm[ntm].end-tm[ntm].start);
		ntm++;
	}

	ckfree(avw);
	return ntm;
}

void rescomp(ALN mult_aln,sint *ntm,TMENTRY **tm)
{
	sint  err,i,j,k,ires,iseq=0;
	sint ix;
	char t[MAXLINE+1];
	char *seq;
	sint *low;

        low=(sint *)ckalloc((mult_aln.nseqs+1)*sizeof(sint));

/* check for low complexity regions */

	for(i=0;i<mult_aln.nseqs;i++) {
		seq=(char *)ckalloc((mult_aln.seqs[i].len+1)*sizeof(char));
		for(j=0,k=0;j<mult_aln.seqs[i].len;j++)
			if(isalpha(mult_aln.seqs[i].data[j])) seq[k++]=toupper(mult_aln.seqs[i].data[j])-'A';
		low[i]=low_complexity(mult_aln.seqs[i].name,seq,k,ntm[i],tm[i]);
		ckfree(seq);
	}

	ckfree(low);

}

/* returns the number of low complexity regions in a sequence */

int low_complexity(char *name,char *seq,int len,sint ntm,TMENTRY *tm)
{
	int i,j,l=0;
	int s,e;
	int hwindow=(WINDOW-1)/2.0;
	int max=0;
	int start=0,end=0,aa=0;
	int naa[26],saa[26],dibenn[26];
	Boolean in_low,found;

	for(i=hwindow;i<len-hwindow-2;i++) {
		for(j=0;j<26;j++) {
			naa[j]=0;
			saa[j]=0;
		}
		max=0;
		start=(-1);
		for(j=(-hwindow);j<hwindow*2+1;j++) {
			aa=seq[i+j];
			if (aa<26) {
				if(naa[aa]==0) saa[aa]=i+j;
				dibenn[aa]=i+j;
				naa[aa]++;
				if(naa[aa]>max) {
					max=naa[aa];
					start=saa[aa];
					end=i+j;
				}
			}
		}
		max=0;
		for(j=0;j<26;j++) {
			max+=naa[j]*naa[j];
		}
		if(max>CUTOFF && start != (-1)) {
			for(j=start;j<=end && j<len;j++) {
				if(seq[j]!=30) l++;
				seq[j]=30;
			}
			found=FALSE;
                	for(j=0;j<ntm;j++)
				if(overlap(start,end+1,tm[j].start,tm[j].end)>1) {
					found=TRUE;
					break;
				}
			if(found==FALSE)
				fprintf(stdout,"LOW %s %d %d %d\n",name,start,end+1,max);
		}
	}

	return l;
}


