#include "principal.h"
#include "lecfi.h"
#include "filtering.h"
#include "kmeans.h"
#include "ecrfi.h"
#include "divide.h"
#include "treebionj.h"
#include "alignment.h"
#include "secatorbionj.h"
#include "treeward.h"
#include "treecut.h"
#include "treedpc.h"

/**********************************************/
/*                                            */
/*Programme principal du package de clustering*/
/*                                            */
/**********************************************/

int main(int argc, char **argv)
{
  /*declaration de variables*/
  int i,j,type_donnees,clustering_method,nb_clusters_selection,nb_clusters_selected;
  int type_densite,weighting,donnees_normalisees,normalisation,individus_orphelins;
  int write_coordinates,filtrage_individus,longueur_alignement,nb_individus,nb_dimensions;
  int nb_clusters;
  char *buf,*fichier_entree,**sequences,nom_fichier[TAILLE_NOM],*output_file;
  double distance_min,seuil_dissimilarite;
  t_individu **individus;
  t_noeud *arbre;
  /*fin declaration de variables*/

  /************************************/
  /*Traitement des parametres d'entree*/
  /************************************/

  /*initialisation de la generation aleatoire de nombres*/
  srand(getpid());

  /*parametres par defaut*/
  weighting=NON;
  donnees_normalisees=NON;
  normalisation=NON;
  individus_orphelins=NON;
  write_coordinates=NON;
  filtrage_individus=NON;
  output_file=NULL;
  type_densite=DENSITE1;
  /*fin parametres par defaut*/

  fichier_entree=strdup(argv[1]);
  if(strcmp(fichier_entree,"-help")==0)
    {
      printf("Program usage : cluspack file options\n\n");
      printf("********************OPTIONS BELOW********************\n\n");
      printf("-data_type=[coordinates|alignment|distances|similarities]\n");
      printf("-clustering_method=[kmeans|ward|bionj]\n");
      printf("-nb_clusters=[secator|dpc|number]  (number is really a number like 4 etc.)\n");
      printf("[-density1|-density2][-normalisation][-normalised_data][-write_coordinates]\n");
      printf("[-filtering_distance=number]\n");
      exit(0);
    }

  for(i=2;i<argc;i++)
    {
      if(strstr(argv[i],"-data_type=")!=NULL)
	{
	  buf=strstr(argv[i],"=")+1;
	  if(strcmp(buf,"coordinates")==0)
	    {
	      type_donnees=COORDONNEES;
	    }
	  else if(strcmp(buf,"alignment")==0)
	    {
	      type_donnees=ALIGNEMENT;
	    }
	  else if(strcmp(buf,"distances")==0)
	    {
	      type_donnees=DISTANCES;
	    }
	  else if(strcmp(buf,"similarities")==0)
	    {
	      type_donnees=SIMILARITES;
	    }
	  else
	    {
	      printf("bad argument for -data_types !\n");
	      exit(1);
	    }
	}
      else if(strstr(argv[i],"-clustering_method=")!=NULL)
	{
	  buf=strstr(argv[i],"=")+1;
	  if(strcmp(buf,"mm")==0)
	    {
	      clustering_method=MIXTURE_MODEL;
	    }
	  else if(strcmp(buf,"kmeans")==0)
	    {
	      clustering_method=KMEANS;
	    }
	  else if(strcmp(buf,"ward")==0)
	    {
	      clustering_method=WARD;
	    }
	  else if(strcmp(buf,"bionj")==0)
	    {
	      clustering_method=BIONJ;
	    }
	  else if(strcmp(buf,"normalized_cut")==0)
	    {
	      clustering_method=NORMALIZED_CUT;
	    }
	  else
	    {
	      printf("bad argument for -clustering_method !\n");
	      exit(1);
	    }
	}
      else if(strstr(argv[i],"-nb_clusters=")!=NULL)
	{
	  buf=strstr(argv[i],"=")+1;
	  if(strcmp(buf,"dpc")==0)
	    {
	      nb_clusters_selection=DPC;
	    }
	  else if(strcmp(buf,"secator")==0)
	    {
	      nb_clusters_selection=SECATOR;
	    }
	  else if(strcmp(buf,"graphpc")==0)
	    {
	      nb_clusters_selection=GRAPHPC;
	    }
	  else
	    {
	      nb_clusters_selected=atoi(buf);
	      nb_clusters_selection=FIXED;
	    }
	}
      else if(strstr(argv[i],"-filtering_distance=")!=NULL)
	{
	  filtrage_individus=OUI;
	  distance_min=atof(strstr(argv[i],"=")+1);
	}
      else if(strstr(argv[i],"-density1")!=NULL)
	{
	  type_densite=DENSITE1;
	}
      else if(strstr(argv[i],"-density2")!=NULL)
	{
	  type_densite=DENSITE2;
	}
      else if(strstr(argv[i],"-weighting")!=NULL)
	{
	  weighting=OUI;
	}
      else if(strstr(argv[i],"-normalised_data")!=NULL)
	{
	  donnees_normalisees=OUI;
	}
      else if(strstr(argv[i],"-normalisation")!=NULL)
	{
	  normalisation=OUI;
	  donnees_normalisees=OUI;
	}
      else if(strstr(argv[i],"-orphan_points")!=NULL)
	{
	  individus_orphelins=OUI;
	}
      else if(strstr(argv[i],"-write_coordinates")!=NULL)
	{
	  write_coordinates=OUI;
	}
      else if(strstr(argv[i],"-output")!=NULL)
	{
	  output_file=strdup(strstr(argv[i],"=")+1);
	}
    }

  /****************************************/
  /*Fin traitement des parametres d'entree*/
  /****************************************/

  /*********************/
  /*                   */
  /*LECTURE DES DONNEES*/
  /*                   */
  /*********************/

  /*lecture des donnees*/
  if(type_donnees==ALIGNEMENT)
    {
      /*lecture du fichier de l'alignement multiple*/
      lecture_fichier_alignement(fichier_entree,&longueur_alignement,&nb_individus,
				 &individus,&sequences);

      nb_dimensions=nb_individus;

      if(nb_clusters_selection==SECATOR)
	{
	  /*calcul des distances entre les sequences*/
	  calcul_distances_sequences(nb_individus,individus,longueur_alignement,sequences);
	}
      else
	{
	  /*calcul des pourcentages d'identite entre les sequences*/
	  calcul_identites_sequences(nb_individus,individus,longueur_alignement,sequences);
	}
    }
  else
    {
      /*lecture du fichier de coordonnees, similarites ou distances*/
      lecture_fichier_coordonnees(&nb_individus,&nb_dimensions,&individus,fichier_entree);
    }

  /***************************/
  /*                         */
  /*PRETRAITEMENT DES DONNEES*/
  /*                         */
  /***************************/

  if(filtrage_individus==OUI)
    {
      /*filtrage des individus suivant la valeur seuil donnee et le type des donnees*/
      filtre_individus(&nb_individus,nb_dimensions,individus,type_donnees,distance_min);

      if((type_donnees==SIMILARITES)||(type_donnees==ALIGNEMENT))
	{
	  nb_dimensions=nb_individus;
	}
    }
  if((nb_clusters_selection==GRAPHPC)&&(type_donnees==COORDONNEES))
    {
      /*calcul des similarites a partir des coordonnees en utilisant les correlations*/
      coordonnees_to_similarites(nb_individus,nb_dimensions,individus);
    }
  if(normalisation==OUI)
    {
      /*on normalise les individus*/
      normalisation_individus(nb_individus,nb_dimensions,individus);
    }

  /************/
  /*          */
  /*CLUSTERING*/
  /*          */
  /************/

  /*clustering method : KMEANS ou NORMALIZED_CUT*/
  if((clustering_method==KMEANS)||(clustering_method==NORMALIZED_CUT))
    {
      /*the number of clusters is fixed*/
      if(nb_clusters_selection==FIXED)
	{
	  kmeans(nb_individus,nb_dimensions,individus,nb_clusters_selected);
	  nb_clusters=nb_clusters_selected;
	}
      /*the number of clusters is automatically found by DPC*/
      else if((nb_clusters_selection==DPC)||(nb_clusters_selection==GRAPHPC))
	{
	  divide(nb_individus,nb_dimensions,&nb_clusters,individus,type_donnees,
		 clustering_method,nb_clusters_selection,donnees_normalisees,type_densite);
	}
    }
  /*clustering method : WARD*/
  else if(clustering_method==WARD)
    {
      classification_ward(nb_individus,nb_dimensions,individus,type_donnees,&arbre);

      /*the number of clusters is fixed*/
      if(nb_clusters_selection==FIXED)
	{
	  nb_clusters_to_dissimilarity_threshold(nb_individus,nb_clusters_selected,arbre,
						 &seuil_dissimilarite);
	}
      /*the number of clusters is found by Secator*/
      else if(nb_clusters_selection==SECATOR)
	{
	  secator_tree(nb_individus,arbre,&seuil_dissimilarite,&nb_clusters);
	}

      if((nb_clusters_selection==FIXED)||(nb_clusters_selection==SECATOR))
	{
	  /*creation des groupes*/
	  decoupage_arbre_seuil_dissimilarite(nb_individus,arbre,seuil_dissimilarite,&nb_clusters);
	}
      else
	{
	  decoupage_arbre_DPC(nb_individus,nb_dimensions,individus,arbre,&nb_clusters,
			      type_donnees,nb_clusters_selection,donnees_normalisees,type_densite);
	}
    }
  /*clustering method : bionj*/
  else if(clustering_method==BIONJ)
    {
      if(nb_individus==1)
	{
	  nb_clusters=1;
	  individus[0]->cluster=0;
	}
      else
	{
	  if(type_donnees==ALIGNEMENT)
	    {
	      creation_arbre_bionj(nb_individus,individus,sequences,fichier_entree,&arbre);
	    }
	  /*the number of clusters is found by Secator*/
	  if((nb_clusters_selection==SECATOR)||(nb_clusters_selection==FIXED))
	    {
	      secator_bionj(nb_individus,arbre,&nb_clusters,weighting,
			    nb_clusters_selection,nb_clusters_selected);
	    }
	}
    }

  /************************/
  /*                      */
  /*ECRITURE DES RESULTATS*/
  /*                      */
  /************************/

  /*ecriture du fichier resultat presentant les clusters*/
  if(output_file==NULL)
    {
      strcpy(nom_fichier,fichier_entree);
      if(strstr(nom_fichier,".")!=NULL)
	{
	  sprintf(strstr(nom_fichier,"."),".clu");
	}
      else
	{
	  strcat(nom_fichier,".clu");
	}
    }
  else
    {
      strcpy(nom_fichier,output_file);
    }

  /*ecriture du fichier resultat*/
  ecriture_fichier_clusters(nb_individus,nb_dimensions,individus,nb_clusters,nb_clusters_selection,
			    individus_orphelins,write_coordinates,nom_fichier);

  if(type_donnees==ALIGNEMENT)
    {
      if(output_file==NULL)
	{
	  strcpy(nom_fichier,fichier_entree);
	}
      else
	{
	  strcpy(nom_fichier,output_file);
	}
      if(strstr(nom_fichier,".")!=NULL)
	{
	  sprintf(strstr(nom_fichier,"."),"2.tfa");
	}
      else
	{
	  strcat(nom_fichier,"2.tfa");
	}

      /*ecriture du fichier de l'alignement multiple avec les sequences*/
      /*reordonnees suivant leurs groupes*/
      ecriture_fichier_clusters_alignement(nom_fichier,longueur_alignement,nb_individus,
					   individus,sequences,individus_orphelins,nb_clusters);
    }

  /*desallocation memoire*/
  for(i=0;i<nb_individus;i++)
    {
      for(j=0;j<individus[i]->nb_individus_similaires;j++)
	{
	  free(individus[i]->individus_similaires[j]->valeurs_brutes);
	  free(individus[i]->individus_similaires[j]->valeurs_traitees);
	  free(individus[i]->individus_similaires[j]->nom);
	  free(individus[i]->individus_similaires[j]);
	}
      if(individus[i]->nb_individus_similaires>0)
	{
	  free(individus[i]->individus_similaires);
	}
      free(individus[i]->nom);
      free(individus[i]->valeurs_brutes);
      free(individus[i]->valeurs_traitees);
    }
  /*fin desallocation memoire*/
  return 0;
}
