#define LICENSE_USER "Enrique Abola"
#define LICENSE_SITE "Protein Data Bank, BNL"
