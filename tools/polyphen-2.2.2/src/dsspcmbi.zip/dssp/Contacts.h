#ifndef _Contacts_h_
#define _Contacts_h_

#ifdef __GNUG__
#  pragma interface
#endif

void CalcResidueCenters();
void AddToAllAtomRadii(double r);

#endif
